# Mascotas originales de iCentral 360°

Generadas con la herramienta integrada ImageGen el 11 de octubre de 2026. Fondo transparente. Los PNG base son avatares; los archivos `*-expressions.png` son atlas 2 × 2 de 1254 × 1254 px, con celdas de 627 px: neutral, parpadeo, atención, listo.

Las expresiones representan el estado de la interfaz. No afirman emociones, trabajo oculto ni una acción ejecutada. Las animaciones se detienen al reducir movimiento y cuando la app está inactiva. No hay dependencias de servicios de mascotas de terceros.

El catálogo contiene nueve mascotas originales. `kora`, `timo`, `milo`, `olmo`, `nova` y `atlas` usan sólo atlas: la miniatura se obtiene de su cuadro neutral con el renderizador Flutter, sin duplicar imágenes. El renderizador recorta el 1% del borde de cada celda para evitar contaminación visual entre expresiones. Los conceptos de personajes clásicos solicitados están fuera del paquete distribuible mientras se revisan sus derechos y versiones; no se presentan como libres de derechos.

## Prompts originales

### lumen

Use case: stylized-concept. Asset type: original mascot avatar for iCentral 360 professional employee assistant. Create a single a small arctic fox with rounded triangular ears, pearly ivory fur, teal ear accents and a tiny magenta collar ring, sitting alert with a subtle kind smile, dark navy eyes. Refined 3D clay collectible rendering, exceptionally polished yet simple readable silhouette at 32px, soft studio lighting and restrained satin materials. Square centered full body with generous transparent padding. No text, no lettering, no watermark, no backdrop, no props beyond described accessory, no other characters, no ground plane. Real transparent background. Approachable to adults, professional, not babyish.

Expresiones: Edit reference mascot into a precise sprite atlas for a professional desktop companion. Produce a square transparent PNG with a 2 columns by 2 rows equal square cell grid, no gridlines or labels. Each cell contains the SAME original character at the SAME size, lighting, position and ground anchor, full body fully contained with 15% padding. Top-left: original neutral alert expression. Top-right: natural blink eyes gently closed, identical body pose. Bottom-left: thoughtful attentive expression, tiny head tilt, same body. Bottom-right: warm pleased smile, small expressive gesture, same body and anchor. Preserve character identity, materials and colors exactly. No backgrounds, no added objects, no text. True alpha transparency throughout empty area.

## Ampliación del catálogo

Los seis atlas nuevos se generaron individualmente con ImageGen el mismo día, fondo transparente, cuadrícula 2×2 y cuatro estados en el orden descrito. Se conservó el PNG original sin edición posterior.

- **Kora:** ajolote coral, vientre marfil, branquias externas redondeadas, ojos azul oscuro y banda turquesa.
- **Timo:** gato gris carbón, hocico y patas marfil, ojos turquesa, cola curva y collar cian con detalle magenta.
- **Milo:** perro beagle de orejas canela, pecho marfil, nariz oscura y pañuelo turquesa con costura magenta.
- **Olmo:** búho de alas cobrizas, cara y vientre marfil, ojos ámbar y pequeñas plumas turquesa y magenta.
- **Nova:** robot marfil, pantalla oval azul oscuro, ojos turquesa luminosos y antena magenta.
- **Atlas:** gorila de pelaje azul carbón, cara y pecho gris claro, ojos cálidos y pulsera turquesa.

Dirección común de generación: polished 3D clay collectible rendering with satin materials and soft studio lighting; approachable to adults; exact 2×2 equal square cells with no gridlines; same full-body character, scale, center and baseline in all cells; transparent alpha; neutral, blink, thoughtful and pleased greeting; no text, branding, watermark, scenery or floor; original identity, not based on existing entertainment characters.

### nexo

Use case: stylized-concept. Asset type: original mascot avatar for iCentral 360 professional employee assistant. Create a single a small rounded penguin with deep navy plumage, pearly ivory face and belly, a small cyan scarf with a magenta stitch, standing upright with a calm capable kind expression. Refined 3D clay collectible rendering, exceptionally polished yet simple readable silhouette at 32px, soft studio lighting and restrained satin materials. Square centered full body with generous transparent padding. No text, no lettering, no watermark, no backdrop, no props beyond described accessory, no other characters, no ground plane. Real transparent background. Approachable to adults, professional, not babyish.

Expresiones: Edit reference mascot into a precise sprite atlas for a professional desktop companion. Produce a square transparent PNG with a 2 columns by 2 rows equal square cell grid, no gridlines or labels. Each cell contains the SAME original character at the SAME size, lighting, position and ground anchor, full body fully contained with 15% padding. Top-left: original neutral alert expression. Top-right: natural blink eyes gently closed, identical body pose. Bottom-left: thoughtful attentive expression, tiny head tilt, same body. Bottom-right: warm pleased smile, small expressive gesture, same body and anchor. Preserve character identity, materials and colors exactly. No backgrounds, no added objects, no text. True alpha transparency throughout empty area.

### brisa

Use case: stylized-concept. Asset type: original mascot avatar for iCentral 360 professional employee assistant. Create a single a small hummingbird with teal plumage, pearly ivory belly, soft cyan wing tips, one tiny magenta accent, gently hovering with wings slightly out, calm curious dark navy eyes. Refined 3D clay collectible rendering, exceptionally polished yet simple readable silhouette at 32px, soft studio lighting and restrained satin materials. Square centered full body with generous transparent padding. No text, no lettering, no watermark, no backdrop, no props beyond described accessory, no other characters, no ground plane. Real transparent background. Approachable to adults, professional, not babyish.

Expresiones: Edit reference mascot into a precise sprite atlas for a professional desktop companion. Produce a square transparent PNG with a 2 columns by 2 rows equal square cell grid, no gridlines or labels. Each cell contains the SAME original character at the SAME size, lighting, position and ground anchor, full body fully contained with 15% padding. Top-left: original neutral alert expression. Top-right: natural blink eyes gently closed, identical body pose. Bottom-left: thoughtful attentive expression, tiny head tilt, same body. Bottom-right: warm pleased smile, small expressive gesture, same body and anchor. Preserve character identity, materials and colors exactly. No backgrounds, no added objects, no text. True alpha transparency throughout empty area.


